package com.bjsxt.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.hotel.R;

public class ComparePrizeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compare_prize);
    }
}