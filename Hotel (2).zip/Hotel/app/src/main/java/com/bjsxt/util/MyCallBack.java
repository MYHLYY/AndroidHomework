package com.bjsxt.util;

public interface MyCallBack {
    void onSuccess(byte[] bytes );
}
